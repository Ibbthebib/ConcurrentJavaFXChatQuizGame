package Server;

import Database.Authentication;
import Database.databases;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;

import static Database.Authentication.AuthenticateUser;


/**
 * The purpose of this class is to have each connection run on a different thread,
 * allowing privacy for two clients conversation. The extends Thread allows the application
 * to have multiple threads executing. This achieves the concurrency of the program.
 */
public class ServerThreads implements Runnable {


    private Socket socket;                      // field variable for Socket
    ObjectOutputStream output;
    public HashMap<String, Socket> privateChat = new HashMap<>();
    Authentication auth = new Authentication();


    /**
     * The following is a constructor for the Socket.
     *
     * @param socket one sided connection(s).
     */
    public ServerThreads(Socket socket) {       // Socket constructor
        this.socket = socket;
    }

    public void sendStringToClient(Object text) throws IOException {

        try {
            if (text instanceof String) {
                output.writeObject((String) (text));
                output.flush();
            } else {
                output.writeObject(text);
                output.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void setSockets4Usernames(String username) {
        privateChat.put(username, this.socket);
//        OnlineUsers.put(username, s);


    }

    public int verifyUser(String username, String password) {
//        System.out.println(auth.AuthenticateUser(username, password));
        if (AuthenticateUser(username, password) == 1) {

            return 1;
        } else {
            return 0;
        }

    }

    public void registeration(String username, String Lastname, String Firstname, String email, String password) {

        try {
            databases.insert(username, Lastname, Firstname, email, password);
        } catch (Exception e) {

            System.out.println("System failed due to " + e.getMessage());
        }

    }


    public void sendStringtoAllClients(Object text) throws IOException {
        System.out.println("Connection pool " + MainServer.arr.size());

        try {
            for (int i = 0; i < MainServer.arr.size(); i++) {

                ServerThreads data = new MainServer().arr.get(i);
                if (text instanceof String) {
                    data.sendStringToClient((String) (text));
                } else {
                    data.sendStringToClient(text);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateOnlineList(){

    }

    /**
     * The purpose of the following method is to retrieve the sockets input and output stream.
     * It further initiates communication. This is done from within the while loop.
     * As long as the client and server continue with their connection, the socket enables
     * messages to be sent back and forth between both parties.
     */
    @Override
    public void run() {
        try {
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            output = new ObjectOutputStream(socket.getOutputStream());

            while (true) {
                /*
                ! represents normal user chat
                @ represents database log in
                £ represents database registering
                $ represents

                 */
                String serverString = (String) input.readObject();
                String[] splinter = serverString.replaceFirst(">", "").split("\n");
                String[] registering = serverString.replaceFirst(",", "").split("\n");
                System.out.println(serverString);

                switch (serverString.toCharArray()[0]) {
                    case ('!'):
                        sendStringtoAllClients(serverString.replaceFirst("!", ""));
                        break;
                    case ('>'):
                        if (AuthenticateUser(splinter[0], splinter[1]) == 1) {
                            sendStringToClient(">");
                            System.out.println("P");
                        } else {

                            sendStringToClient("Failed");
                            System.out.println("F");
                        }
                        break;
                    case (','):
                        System.out.println((registering[0] + " " + registering[1] + " " + registering[2] + " " + registering[3] + " " + registering[4]));

                        registeration(registering[0], registering[1], registering[2], registering[3], registering[4]);
                        break;
                    case ('¡'):

                        sendStringtoAllClients(serverString );
                        break;
                    default:
//                        sendStringtoAllClients("Error in fullfilling request");


                }
//                if(serverString.substring(0,2).equals("!")){
//                    sendStringtoAllClients(serverString.replaceFirst("!", ""));}
//
//                else if ((serverString.substring(0,2).equals("*"))) {
//                    System.out.println(user.getName());
//                    sendStringToClient("Verified");
//                    System.out.println("Verified");
//                }


//                System.out.println("Received client message : " + serverString);

            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("message" + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

