package ChatRoomUI;

import java.io.Serializable;

public class MessageHistory implements Serializable {



}
