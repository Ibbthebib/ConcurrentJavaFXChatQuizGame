package ChatRoomUI;

import Server.ServerThreads;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public class ClientConnection extends Thread {
    Socket socket;
    ObjectInputStream input;
    ObjectOutputStream output;
    public User user;
    ServerThreads s = new ServerThreads(socket);
    ScheduledThreadPoolExecutor threadpool = new ScheduledThreadPoolExecutor(10);
    public ObservableList<String> chatLog = FXCollections.observableArrayList();
    public ObservableList<String> gameScore = FXCollections.observableArrayList();
    public boolean isVerified = false;
    Media sound = new Media(new File("/Users/ibbys/Desktop/SWWProject/iphone-ding-sound.mp3").toURI().toString());
    Media ping = new Media(new File("/Users/ibbys/Desktop/SWWProject/src/Bouncy_Bounce-Bugs_Bunny-1735935456.mp3").toURI().toString());
    MediaPlayer mediaPlayer;

    public ClientConnection(Socket socket, User user) throws IOException {
        this.socket = socket;
        this.user = user;


    }


    public void sendMessagetoServer(String data) {
        try {
            System.out.println("IM the data " + data);
            output.writeObject(data);
            output.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String activeMembers(ArrayList<String> users) {
        String sample = "";
        for (String s : users) {
            sample += s + "\n";
        }
        return sample;
    }

    public void setVerifiedStatus(boolean value) {
        this.isVerified = value;
    }

    public void run() {

        try {


            output = new ObjectOutputStream(socket.getOutputStream());
            input = new ObjectInputStream(socket.getInputStream());

//            sendMessagetoServer("Username: " + user.getName());


            while (true) {
                try {

                    String inputFromServer = (String) input.readObject();
                    System.out.println("Input from server: " + inputFromServer);

                    if (inputFromServer.equals(">")) {
                        setVerifiedStatus(true);
                    }

     if(inputFromServer.substring(0,1).equals("¡")) {

         Platform.runLater(new Runnable() {
             @Override
             public void run() {

                 gameScore.add(inputFromServer.replaceAll("¡",""));

             }
         });

     } else {
/*
                    Essentially the event dispatch thread for JavaFX
 */

         Platform.runLater(new Runnable() {

             public void run() {
//                            System.out.println(inputFromServer);

                 chatLog.add(inputFromServer);
                 if (!inputFromServer.contains("PING")) {
                     System.out.println("Hey im not working");
                     mediaPlayer = new MediaPlayer(sound);
                     mediaPlayer.play();
                 } else {
                     mediaPlayer = new MediaPlayer(ping);
                     mediaPlayer.play();

                 }

             }

         });
     }
                } catch (EOFException e) {
                    e.printStackTrace();
                    close();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            close();

        }

    }


    public void close() {
        try {
            input.close();
            output.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

