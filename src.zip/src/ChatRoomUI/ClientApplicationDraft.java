package ChatRoomUI;

import Game.UserInterface;
import QuestionQuiz.QuestionReader;
import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;

public class ClientApplicationDraft extends Application {
    User user;
    private String username;
    private String password;
    //    private ArrayList<Thread> threads;
    private static Stage primaryStage;
    private Game.UserInterface game;
    private static final Font font = Font.font(36);
    private static final Font gameOverFont = Font.font(60);
    private static final Font sPaneFont = Font.font(18);
    private static sidePane spane = new sidePane();
    private QuestionPane Qpane = new QuestionPane();
    private MyProfile profile = new MyProfile();
    QuestionReader read;
    int questioncounter = 0;
    ScheduledThreadPoolExecutor threadPool = new ScheduledThreadPoolExecutor(10);
    boolean isVerified = false;
    int score = 0;
    String temp = "";
    Label scorer = new Label("Score : 0");
    Media sound = new Media(new File("/Users/ibbys/Desktop/SWWProject/src/Countdown - Clock Only.mp3").toURI().toString());
    MediaPlayer player;


    int time = 60;
    String tmp = "";
    Label timer = new Label("Time : 60");
    Timeline animated = new Timeline();
    Label gameOverr = new Label("");
    ListView<String> scores = new ListView<>();


    TranslateTransition timerMovement = new TranslateTransition();
//    JavaSoundRecorder ibby = new JavaSoundRecorder();

    public ClientApplicationDraft() throws IOException {
        read = new QuestionReader("/Users/ibbys/Desktop/SampleQuiz.txt");
    }


    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws Exception {
        // TODO Auto-generated method stub
//        threads = new ArrayList<Thread>();
        stage.setTitle("Group chat");
        stage.setScene(starter(stage));
        stage.show();
    }


    public Scene chatroomUI(Stage primaryStage) throws IOException, InterruptedException {
        /* Make the root pane and set properties */
        System.out.println(username);
        user = new User(username, password);
        Thread userThread = new Thread(user);
        userThread.setDaemon(true);
        userThread.join();
        threadPool.execute(userThread);

        GridPane rootPane = new GridPane();

        rootPane.setPadding(new Insets(40, 40, 40, 40));
        rootPane.setAlignment(Pos.BASELINE_LEFT);

        rootPane.setHgap(50);
        rootPane.setVgap(50);
        Button viewFriends = new Button("Start");
        Button onlineUsers = new Button("Online users");
        Button playGame = new Button("Game");
        Button revision = new Button("Revision");
        Button viewProfile = new Button("My Profile");


        System.out.println(threadPool);
        /*
        Setting online users on the Pane.
         */
        VBox onlineuserPane = new VBox();
        ListView<String> onlineUsersList = new ListView<>();
//        onlineUsersList.setItems(user.client.Onlineusers);
        onlineUsersList.refresh();
        onlineuserPane.getChildren().add(onlineUsersList);

        /*
         * Make the Chat's listView and set it's source to the Client's chatLog
         * ArrayList
         */

        ListView<String> chatListView = new ListView<String>();
        chatListView.setItems(user.client.chatLog);

        chatListView.refresh();
        chatListView.setEditable(false);
        chatListView.getOnScrollTo();
        chatListView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                /**
                 * PrivateChat
                 *
                 */

                privateChat(new Stage());


            }
        });


        viewProfile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    profile = new MyProfile();
                    /*
                    Input users details from database.
                     */
                    profile.recievingUserInfo(user.getName1(), "Users name from database", "Users email from database", "Users module program from DB");
                    profile.start(new Stage());
                    Thread.sleep(1000);
                    profile.getUserInfo();
                    System.out.println(profile.getUserInfo());
                    //                    profile.start(primaryStage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        viewFriends.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

            }
        });
        onlineUsers.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

            }
        });

        playGame.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {


                game = new UserInterface();
                game.start(new Stage());


            }
        });
        revision.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    createContent(new Stage());
//                    createContent();
//                    primaryStage.setScene(createContent());
                } catch (IOException e) {
                    e.printStackTrace();
                }
//                primaryStage.show();
            }

        });

        /*
         * Make the chat text box and set it's action to send a message to the
         * server
         */
        TextField chatTextField = new TextField();
        chatTextField.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                // TODO Auto-generated method stub
                user.client.sendMessagetoServer("!" + user.getName1() + " : " + chatTextField.getText());
                chatTextField.clear();
            }
        });

        /* Add the components to the root pane */
        rootPane.add(chatListView, 0, 0, 5, 3);
//        onlineUsersList.refresh();
        rootPane.add(chatTextField, 0, 3, 5, 2);
        rootPane.add(onlineUsersList, 6, 0, 1, 1);
        rootPane.add(viewFriends, 6, 1);
        rootPane.add(playGame, 6, 2);
        rootPane.add(onlineUsers, 6, 3);
        rootPane.add(revision, 6, 4);
        rootPane.add(viewProfile, 6, 5);

        /* Make and return the scene */
        return new Scene(rootPane, 700, 600);

    }

    public void privateChat(Stage primaryStage) {
        GridPane chatbox = new GridPane();

        ListView<String> chatlog = new ListView<>();
        chatlog.setItems(user.client.chatLog);
        TextField userInput = new TextField();
        userInput.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                user.client.sendMessagetoServer(userInput.getText());
            }
        });

        chatbox.add(chatlog, 0, 0);
        chatbox.add(userInput, 0, 1);

        Scene root = new Scene(chatbox);

        primaryStage.setScene(root);

        primaryStage.show();
    }

    public void createContent(Stage primaryStage) throws IOException {
        GridPane root = new GridPane();
        root.setHgap(50);
        root.setAlignment(Pos.CENTER);
        root.setVgap(50);
        root.setPadding(new Insets(50, 50, 50, 50));
        root.setPrefSize(1000, 600);

/*
Circle object that moves in sync with the countdown timer.
 */
        Circle circle = new Circle();
        circle.setRadius(20);
        circle.setLayoutX(20);
        circle.setLayoutY(20);
        circle.setStroke(Color.PURPLE);
        circle.setFill(Color.PURPLE);
/*
Timer animation system that allows the circle to move from right to left.
 */

        timerMovement = new TranslateTransition();
        /*
        Where it should reach on x
         */
        timerMovement.setToX(650);
        /*
        duration
         */
        timerMovement.setDuration(Duration.seconds(10));
        timerMovement.setAutoReverse(true);
        timerMovement.setCycleCount(Animation.INDEFINITE);
        timerMovement.setNode(circle);
        timerMovement.play();

        animated = new Timeline(new KeyFrame(Duration.seconds(1), e -> settingLabel()));
        animated.setCycleCount(Timeline.INDEFINITE);
        animated.play();
        timer.setFont(font);
        scorer.setFont(font);

        scores.setLayoutX(5);
        scores.setLayoutY(100);
        scores.setItems(user.client.gameScore);


        nextQuestion();
        root.add(Qpane, 0, 1, 3, 1);
        root.add(spane, 4, 1);
        root.add(timer, 2, 0);
        root.add(circle, 0, 3);
        root.add(scorer, 5, 0);
        root.add(gameOverr, 2, 2);
        root.add(scores, 5, 2, 1, 2);
//        root.add(timer, 2, 0);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
//        return new Scene(root, 1000, 800);

    }

    public void nextQuestion() throws FileNotFoundException {
        /*
        Reads next question in from DB ideally.
         */

        Qpane.setQuestion(new Question(read.Question(questioncounter), read.Answer(questioncounter)));
        questioncounter++;
        spane.selectNext();

    }


    private class QuestionPane extends VBox {
        private Text text = new Text();
        private Question currentq;

        public QuestionPane() {
            text.setFont(font);
            HBox box = new HBox();

            Label correctA = new Label();
                /*
                Setting the user text for the game.
                 */
            Button nextQ = new Button();
            nextQ.setText("Next Question?");
            nextQ.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    try {
                        nextQuestion();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            });


            TextField userInput = new TextField();
            userInput.setAlignment(Pos.CENTER);
            userInput.setLayoutX(50);
            userInput.setPrefColumnCount(50);
            userInput.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                        /*
                        Handles whether a correct question  has been  inputted. if so it shows the next question.
                         */
                    String[] userInp = userInput.getText().split(" ");
                    String[] correctAnswer = currentq.getCorrectAnswer().split(" ");


                    if (userInp[0].equals(correctAnswer[0])) {
                        correctA.setTextFill(Color.GREEN);
                        correctA.setText("Correct!");
                        userInput.clear();
                        score += 10;
                        temp = "Score : " + score;
                        scorer.setText(temp);

                        user.client.sendMessagetoServer("¡" + username + "'s current score : " + score);


                        try {
                            nextQuestion();
                        } catch (FileNotFoundException e) {

                        }

                    } else {
                        correctA.setTextFill(Color.RED);
                        correctA.setFont(font);
                        correctA.setText("Incorrect answer!");
                        score -= 5;
                        user.client.sendMessagetoServer("¡" + username + "'s current score : " + score);

                        temp = "Score : " + score;
                        scorer.setText(temp);

                    }
                }
            });

            box.getChildren().add(userInput);


            setAlignment(Pos.CENTER);

            getChildren().addAll(text, box, correctA, nextQ);


        }


        public void setQuestion(Question question) {
            /*
            Setting the current question for the user.
             */
            currentq = question;
            text.setText(question.name);
        }
    }

    private static class sidePane extends VBox {
        private int current = 0;

        /*
        Sidepane to keep track of completed and remaining questions.
         */
        public sidePane() {
            for (int i = 0; i < 15; i++) {
                Text text = new Text("Question : " + i);
                text.setFont(sPaneFont);
                text.setFill(i == current ? Color.BLACK : Color.GREY);
                getChildren().add(text);
            }
        }

        public void selectNext() {
            Text text = (Text) getChildren().get(0 + current);
            text.setFill(Color.GREY);
            current++;
            text.setFill(Color.BLACK);
        }
    }


    private static class Question {
        /*
        The shell of the Question and its possible answers.
         */
        private String name;
        private List<String> answers;

        public Question(String name, String... answers) {
            this.name = name;
            this.answers = Arrays.asList(answers);

        }

        public String getCorrectAnswer() {
            return answers.get(0);
        }
    }

    /*
    Setting countdown visual for Quiz plus stopping the visualisation once time has ran out.
     */
    private void settingLabel() {
        if (time > 0) {
            time--;

        } else {
            timerMovement.stop();
            gameOverr.setText("Game Over!");
            gameOverr.setFont(gameOverFont);
            gameOverr.setTextFill(Color.RED);
        }

        tmp = "Time : " + time;
        timer.setText(tmp);
        if (time == 30) {
            player = new MediaPlayer(sound);
            player.play();
        }

    }

    public void gameOver(Stage primaryStage) {
        GridPane root = new GridPane();

        Label gameOverr = new Label("GAME OVER");
        gameOverr.setFont(gameOverFont);
        gameOverr.setTextFill(Color.RED);
        Scene scene = new Scene(root);

        root.add(gameOverr, 0, 0);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    /*
    The inital screen.
     */
    public Scene starter(Stage primaryStage) {
        this.primaryStage = primaryStage;
        /* Make the root pane and set properties */
        GridPane rootPane = new GridPane();
        rootPane.setPadding(new Insets(20));
        rootPane.setVgap(10);
        rootPane.setHgap(10);
        rootPane.setAlignment(Pos.CENTER);
        // Username Label
        Label userNameLabel = new Label("Username :");
        userNameLabel.setPrefHeight(30);
        userNameLabel.setPrefWidth(150);
        // Username TextField
        TextField userNameText = new TextField();
        userNameText.setPrefHeight(30);
        userNameText.setPrefWidth(200);
        // UserNameLabel for the UserNameText
        userNameLabel.setLabelFor(userNameText);

        // PasswordLabel
        Label passwordLabel = new Label("Password :");
        passwordLabel.setPrefHeight(30);
        passwordLabel.setPrefWidth(150);
        // Password  TextField
        PasswordField passwordText = new PasswordField();
        passwordText.setPrefHeight(30);
        passwordText.setPrefWidth(200);
        // PasswordLabel for the PasswordText
        passwordLabel.setLabelFor(passwordText);

        VBox labelBox = new VBox();
        labelBox.getChildren().add(userNameLabel);
        labelBox.getChildren().add(passwordLabel);
        labelBox.setAlignment(Pos.CENTER);
        labelBox.setSpacing(20);

        VBox textBox = new VBox();
        textBox.getChildren().add(userNameText);
        textBox.getChildren().add(passwordText);
        textBox.setAlignment(Pos.CENTER);
        textBox.setSpacing(20);

        HBox signUpTextBox = new HBox();
        signUpTextBox.getChildren().add(labelBox);
        signUpTextBox.getChildren().add(textBox);
        signUpTextBox.setAlignment(Pos.CENTER);
        signUpTextBox.setSpacing(-10);

        // button registerButton
        Button loginButton = new Button("Login");
        loginButton.setPrefHeight(30);
        loginButton.setPrefWidth(150);
        // register Button
        Button registerButton = new Button("Register");
        registerButton.setPrefHeight(30);
        registerButton.setPrefWidth(150);

        HBox buttonBox = new HBox();
        buttonBox.getChildren().add(loginButton);
        buttonBox.getChildren().add(registerButton);
        buttonBox.setPrefHeight(50);
        buttonBox.setPrefWidth(100);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setSpacing(10);

        BorderPane pane = new BorderPane();
        pane.setCenter(signUpTextBox);
        pane.setBottom(buttonBox);

        Scene scene = new Scene(pane, 600, 250);


        primaryStage.setTitle("Login");
        primaryStage.setScene(scene);
        primaryStage.show();

        Label errorLabel = new Label();
        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent Event) {
                // TODO Auto-generated method stub
                /* Instantiate the client class and start it's thread */

                try {
                    user = new User(userNameText.getText(), passwordText.getText());
                    username = userNameText.getText();
                    password = passwordText.getText();

                    Thread userThread = new Thread(user);
                    userThread.setDaemon(true);
                    threadPool.execute(userThread);


                    Service<Void> service = new Service<Void>() {
                        @Override
                        protected Task<Void> createTask() {
                            return new Task<Void>() {
                                @Override
                                protected Void call() throws Exception {
                                    user.client.sendMessagetoServer(">" + userNameText.getText() + "\n" + passwordText.getText());

                                    //Background work
                                    final CountDownLatch latch = new CountDownLatch(1);
                                    Platform.runLater(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                //FX Stuff done here
                                                if (user.client.isVerified != true) {
                                                    Thread.sleep(1000);
                                                }
                                                System.out.println("APP " + user.client.isVerified);
                                                if (user.client.isVerified == true) {

                                                    /* Change the scene of the primaryStage */
                                                    primaryStage.close();
                                                    primaryStage.setScene(chatroomUI(primaryStage));
                                                    primaryStage.show();
                                                } else {
                                                    errorLabel.setText("Please register!");
                                                    errorLabel.setTextFill(Color.RED);
                                                }

                                            } catch (InterruptedException | IOException e) {
                                                e.printStackTrace();
                                            } finally {
                                                latch.countDown();
                                            }
                                        }
                                    });
                                    //Keep with the background work
                                    return null;
                                }
                            };
                        }
                    };
                    service.start();
                    //                        user.client.sendMessagetoServer(".");

//					else{
//						errorLabel.setTextFill(Color.RED);
//						errorLabel.setText("You need to register!");
//					}
//                    service.restart();


//                            System.out.println(user.client.isVerified + " not in thread");


                } catch (NumberFormatException | IOException e) {
                    // TODO Auto-generated catch block
                    errorLabel.setTextFill(Color.RED);
                    errorLabel.setText("Unexecpted error please shut down!");
                }

            }
        });

        registerButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                /* Change the scene of the primaryStage */
                primaryStage.close();
                primaryStage.setScene(register(primaryStage));
                primaryStage.show();
            }


        });

        /*
         * Add the components to the root pane arguments are (Node, Column
         * Number, Row Number)
         */
        rootPane.add(userNameLabel, 0, 0);
        rootPane.add(userNameText, 1, 0);
        rootPane.add(passwordLabel, 0, 1);
        rootPane.add(passwordText, 1, 1);
        rootPane.add(loginButton, 0, 2);
        rootPane.add(registerButton, 1, 2);
//		rootPane.add(submitClientInfoButton, 0, 3, 2, 1);
        rootPane.add(errorLabel, 0, 4);
        /* Make the Scene and return it */
        return new Scene(rootPane, 600, 250);
    }

    public void setVerified(boolean value) {
        isVerified = value;
    }


    public Scene register(Stage primaryStage) {
        this.primaryStage = primaryStage;
        GridPane rootPane = new GridPane();
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.CENTER);
        rootPane.setHgap(10);
        rootPane.setVgap(10);

        // FirstName Label
        Label firstNameLabel = new Label("First Name :");
        firstNameLabel.setPrefHeight(30);
        firstNameLabel.setPrefWidth(150);
        // FirstName TextField
        TextField firstNameText = new TextField();
        firstNameText.setPrefHeight(30);
        firstNameText.setPrefWidth(200);
        // FirstNameLabel for the FirstNameText
        firstNameLabel.setLabelFor(firstNameText);  // label is for this input box

        // LastName Label
        Label lastNameLabel = new Label("Last Name :");
        lastNameLabel.setPrefHeight(30);
        lastNameLabel.setPrefWidth(150);
        // LastName TextField
        TextField lastNameText = new TextField();
        lastNameText.setPrefHeight(30);
        lastNameText.setPrefWidth(200);
        // LastNameLabel for the LastNameText
        lastNameLabel.setLabelFor(lastNameText);

        // Username Label
        Label userNameLabel = new Label("Username :");
        userNameLabel.setPrefHeight(30);
        userNameLabel.setPrefWidth(150);
        // Username TextField
        TextField userNameText = new TextField();
        userNameText.setPrefHeight(30);
        userNameText.setPrefWidth(200);
        // UserNameLabel for the UserNameText
        userNameLabel.setLabelFor(userNameText);

        // PasswordLabel
        Label passwordLabel = new Label("Password :");
        passwordLabel.setPrefHeight(30);
        passwordLabel.setPrefWidth(150);
        // Password  TextField
        TextField passwordText = new TextField();
        passwordText.setPrefHeight(30);
        passwordText.setPrefWidth(200);
        // PasswordLabel for the PasswordText
        passwordLabel.setLabelFor(passwordText);

        // E-mail Label
        Label emailLabel = new Label("E-mail :");
        emailLabel.setPrefHeight(30);
        emailLabel.setPrefWidth(150);
        // e-mail TextField
        TextField emailText = new TextField();
        emailText.setPrefHeight(30);
        emailText.setPrefWidth(200);
        // E-mail for the LastNameText
        lastNameLabel.setLabelFor(emailText);


        VBox labelBox = new VBox();
        labelBox.getChildren().add(firstNameLabel);
        labelBox.getChildren().add(lastNameLabel);
        labelBox.getChildren().add(userNameLabel);
        labelBox.getChildren().add(emailLabel);
        labelBox.getChildren().add(passwordLabel);
        labelBox.setAlignment(Pos.CENTER);
        labelBox.setSpacing(20);

        VBox textBox = new VBox();
        textBox.getChildren().add(firstNameText);
        textBox.getChildren().add(lastNameText);
        textBox.getChildren().add(userNameText);
        textBox.getChildren().add(emailText);
        textBox.getChildren().add(passwordText);
        textBox.setAlignment(Pos.CENTER);
        textBox.setSpacing(20);

        HBox signUpTextBox = new HBox();
        signUpTextBox.getChildren().add(labelBox);
        signUpTextBox.getChildren().add(textBox);
        signUpTextBox.setAlignment(Pos.CENTER);
        signUpTextBox.setSpacing(-10);

        // button registerButton
        Button submitButton = new Button("Submit");
        submitButton.setPrefHeight(30);
        submitButton.setPrefWidth(150);

        // Cancel Button
        Button cancelButton = new Button("Cancel");
        cancelButton.setPrefHeight(30);
        cancelButton.setPrefWidth(150);

        HBox buttonBox = new HBox();
        buttonBox.getChildren().add(submitButton);
        submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
				/*
				Send details to database for registration.
//				 */
                System.out.println(Platform.isFxApplicationThread());

                try {
                    user = new User(userNameText.getText(), passwordText.getText());
                    Thread userThread = new Thread(user);
                    userThread.setDaemon(true);
                    threadPool.execute(userThread);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Service<Void> service = new Service<Void>() {
                    @Override
                    protected Task<Void> createTask() {
                        return new Task<Void>() {
                            @Override
                            protected Void call() throws Exception {
                                Platform.runLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        user.client.sendMessagetoServer("," + userNameText.getText() + "\n" + lastNameText.getText() + "\n"
                                                + firstNameText.getText() + "\n" + emailText.getText() + "\n" + passwordText.getText());
                                    }
                                });

                                //Background work
                                //Keep with the background work
                                return null;
                            }
                        };
                    }
                };
                service.start();

                primaryStage.close();
                primaryStage.setScene(starter(primaryStage));
                primaryStage.show();


            }


        });

        cancelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
                primaryStage.setScene(starter(primaryStage));
                primaryStage.show();
            }

        });


        buttonBox.getChildren().add(cancelButton);
        buttonBox.setPrefHeight(50);
        buttonBox.setPrefWidth(100);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setSpacing(10);

        BorderPane pane = new BorderPane();
        pane.setCenter(signUpTextBox);
        pane.setBottom(buttonBox);
        Scene scene = new Scene(pane, 600, 250);


        primaryStage.setTitle("Register");
        primaryStage.setScene(scene);
        primaryStage.show();

        rootPane.add(userNameLabel, 0, 0);
        rootPane.add(userNameText, 1, 0);
        rootPane.add(passwordLabel, 0, 1);
        rootPane.add(passwordText, 1, 1);
        rootPane.add(firstNameLabel, 0, 2);
        rootPane.add(firstNameText, 1, 2);
        rootPane.add(lastNameLabel, 0, 3);
        rootPane.add(lastNameText, 1, 3);
        rootPane.add(emailLabel, 0, 4);
        rootPane.add(emailText, 1, 4);
        rootPane.add(cancelButton, 0, 5);
        rootPane.add(submitButton, 1, 5);
        /* Make the Scene and return it */
        return new Scene(rootPane, 600, 250);


    }
}
