package Database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class databases {

    // search insert update delete

    //-----------------------Search-----------------------
    public static void selectAll() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = JDBCUtils.getConnection();

            System.out.println("Whether successfully connect to the databases" + conn);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from users");

            // print out all the data in the table
            while (rs.next()) {
                System.out.println(rs.getString(1) + "," + rs.getString(2) + rs.getString(3) + "," + rs.getString(4)
                        + "," + rs.getString(5));

            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        } finally {
            JDBCUtils.close(rs, stmt, conn);
        }

    }

    // check whether the input username and password successully match the username
    // and password in the databases.
    public static boolean selectByUsernamePassword(String username, String password) {
        // in order to catch exception, the variables have to be local variables.
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = JDBCUtils.getConnection();

            stmt = conn.createStatement();

            String sql = "select * from users where username = '" + username + "' and password = '" + password + "'";
            rs = stmt.executeQuery(sql);

            // as search based on the username and password, there are only two result: get
            // one set of data, or nothing.
            if (rs.next()) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            JDBCUtils.close(rs, stmt, conn);
        }
        return false;
    }

    // -----------------------Insert-----------------------
    public static void insert(String username, String Lastname,String Firstname, String email, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "insert into users(username, last_name, first_name, email, password) values (?,?,?,?,?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2,Lastname);
            stmt.setString(3, Firstname);
            stmt.setString(4,email);
            stmt.setString(5,password);

            int result = stmt.executeUpdate();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        } finally {
            JDBCUtils.close(rs, stmt, conn);
        }
    }

    // -----------------------Update-----------------------
    //update the password
    public static void update(String username, String newPassword) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "update users set password = ? where username = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, newPassword);
            stmt.setString(2, username);

            int result = stmt.executeUpdate();
            // if the username exists, delete one row, otherwise, fail to delete
            if(result > 0) {
                System.out.println("successfull update!");
            }else {
                System.out.println("fail to update");
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        } finally {
            JDBCUtils.close(rs, stmt, conn);
        }
    }



    // -----------------------Delete-----------------------
    public static void delete(String username) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "delete from users where username = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);

            int result = stmt.executeUpdate();
            // if the username exists, delete one row, otherwise, fail to delete
            if(result > 0) {
                System.out.println("successfull delete!");
            }else {
                System.out.println("fail to delete");
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        } finally {
            JDBCUtils.close(rs, stmt, conn);
        }
    }



    public static void main(String[] args) {
        //selectAll();
        // System.out.println(selectByUsernamePassword("Jay", "123456"));
        insert("Iris","Yi", "Yi", "iris@gmail.com", "123123");
        //delete("Iris");
//        update("Jay","654321");

    }
}

