package Server;

import ChatRoomUI.Message;
import Database.Authentication;
import Database.DatabasePersonal;
import Database.databases;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

import static Database.Authentication.AuthenticateUser;


/**
 * The purpose of this class is to have each connection run on a different thread,
 * allowing privacy for two clients conversation. The extends Thread allows the application
 * to have multiple threads executing. This achieves the concurrency of the program.
 */
public class ServerThreads implements Runnable {


    private Socket socket;                      // field variable for Socket
    ObjectOutputStream output;
    public HashMap<String, ObjectOutputStream> privateChat = new HashMap<>();
    Authentication auth = new Authentication();
    Message serverString;


    /**
     * The following is a constructor for the Socket.
     *
     * @param socket one sided connection(s).
     */
    public ServerThreads(Socket socket) {       // Socket constructor
        this.socket = socket;
    }

    public void sendStringToClient(Object text) throws IOException {

        try {
            if (text instanceof String) {
                System.out.println(text);
                output.writeObject((String) (text));
                output.flush();
            } else {
                output.writeObject(text);
                output.flush();
            }
        } catch(SocketException e){
            e.getMessage();
        }

    }

    public void sendPrivate(String username, String text) throws IOException {
        ObjectOutputStream sender = privateChat.get(username);
        sender.writeObject(text);
        sender.flush();
//        OnlineUsers.put(username, s);


    }

    public int verifyUser(String username, String password) throws IOException {
//        System.out.println(auth.AuthenticateUser(username, password));
        if (AuthenticateUser(username, password) == 1) {

            return 1;
        } else {
            return 0;
        }

    }

    public void registeration(String username, String Lastname, String Firstname, String email, String password) {

        try {
            databases.insert(username, Lastname, Firstname, email, password);
        } catch (Exception e) {

            System.out.println("System failed due to " + e.getMessage());
        }

    }


    public void sendStringtoAllClients(Object message) throws IOException {
        System.out.println("Connection pool " + MainServer.arr.size());

        try {
            for (int i = 0; i < MainServer.arr.size(); i++) {

                ServerThreads data = new MainServer().arr.get(i);
                if (message instanceof Message) {
                    data.sendStringToClient(message);
                } else {
//                    data.sendStringToClient(message);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateOnlineList() {

    }

    public  int getUserId(String username){
       return DatabasePersonal.searchID(username);

    }
    public String userDetails(int id){

        return DatabasePersonal.searchUsername(id) + "\n" + DatabasePersonal.searchName(id) +
                "\n" + DatabasePersonal.searchEmail(id) + "\n" + DatabasePersonal.searchProgram(id);

    }
    public void updateUserDetails(String user, String userName, String email, String program){
       DatabasePersonal.updatePersonalUsername(userName,DatabasePersonal.searchID(user));
       DatabasePersonal.updatePersonalEmail(email,DatabasePersonal.searchID(userName));
       DatabasePersonal.updatePersonalProgram(program,DatabasePersonal.searchID(userName));
    }

    public void deleteUserDetails(String userName){
        DatabasePersonal.delete(DatabasePersonal.searchID(userName));

    }
    /**
     * The purpose of the following method is to retrieve the sockets input and output stream.
     * It further initiates communication. This is done from within the while loop.
     * As long as the client and server continue with their connection, the socket enables
     * messages to be sent back and forth between both parties.
     */
    @Override
    public void run() {
        try {
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            output = new ObjectOutputStream(socket.getOutputStream());

            while (true) {
                /*
                ! represents normal user chat
                @ represents database log in
                £ represents database registering
                $ represents

                 */
                serverString = (Message) input.readObject();

                System.out.println(serverString.getMessage());
                String[] splinter = serverString.getMessage().replaceFirst(">", "").split("\n");
                String[] registering = serverString.getMessage().replaceFirst(",", "").split("\n");
                String[] userDetails = serverString.getMessage().replaceFirst("ª", "").split(" ");
                for(String s : userDetails){
                    System.out.println(s + " test");
                }

//                System.out.println(serverString);

                switch (serverString.getMessage().toCharArray()[0]) {
                    case ('!'):
                        serverString.setMessage(serverString.getMessage().replaceFirst("!", ""));
                        if(serverString == null){
                            System.out.println("ITs nullll");
                        }
                        sendStringtoAllClients(serverString);
                        break;
                    case ('>'):
                        if (AuthenticateUser(splinter[0], splinter[1]) == 1) {
//                            privateChat.put(splinter[0], output);
                            serverString.setMessage(">");
                            sendStringToClient(serverString);
                            System.out.println("P");
                        } else {

                            sendStringToClient("Failed");
                            System.out.println("F");
                        }
                        break;
                    case (','):
                        System.out.println((registering[0] + " " + registering[1] + " " + registering[2] + " " + registering[3] + " " + registering[4]));

                        registeration(registering[0], registering[1], registering[2], registering[3], registering[4]);
                        break;
                    case ('¡'):

                        sendStringtoAllClients(serverString);
                        break;
                        case ('º'):

                            serverString.setMessage("º"+ userDetails(getUserId(serverString.getMessage().replaceFirst("º",""))));

                        sendStringtoAllClients(serverString);
                        case ('ª'):

                            try {
                                updateUserDetails(userDetails[0], userDetails[1], userDetails[2], userDetails[3]);
                            } catch(ArrayIndexOutOfBoundsException e){

                            }
                            System.out.println("succesful update!");
                        break;
                        case ('¢'):

                            try {
                                deleteUserDetails(serverString.getMessage().replaceAll("¢",""));
                            } catch(ArrayIndexOutOfBoundsException e){

                            }
                            System.out.println("succesful update!");
                        break;
                    default:
                        System.out.println(serverString.getMessage());

                }

//                if(serverString.substring(0,2).equals("!")){
//                    sendStringtoAllClients(serverString.replaceFirst("!", ""));}
//
//                else if ((serverString.substring(0,2).equals("*"))) {
//                    System.out.println(user.getName());
//                    sendStringToClient("Verified");
//                    System.out.println("Verified");
//                }


//                System.out.println("Received client message : " + serverString);

            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("message" + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

